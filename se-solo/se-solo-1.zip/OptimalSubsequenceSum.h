#ifndef OPTIMAL_SUBSEQUENCE_SUM_H
#define OPTIMAL_SUBSEQUENCE_SUM_H

int maximalSubsequenceSum(int sequence[], int length);

#endif 